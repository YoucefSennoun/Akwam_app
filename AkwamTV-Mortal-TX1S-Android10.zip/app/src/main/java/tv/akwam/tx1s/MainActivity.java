package tv.akwam.tx1s;

import android.app.Activity;
import android.content.ComponentCallbacks2;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;

/**
 * Engineered specifically for Mortal TX1-S (Allwinner H313, Mali-G31, 1GB DDR3 RAM, 8GB ROM, Android 10).
 * - Connects to the Ad-Free D-Pad TV UI (https://ais-dev-pzc2kbcbmy6soqn6ukeiny-637113962636.europe-west2.run.app) with fallback to https://akwam.ss
 * - Blocks 100% of ad networks, popunders, hide.js, hide2.js at the network layer (0 RAM wasted)
 * - Bridges legacy SSL certificates on *.downet.net video mirrors on Android 10
 * - Supports VLC & MX Player hardware-decoded external intents
 */
public class MainActivity extends Activity {

    private static final String PRIMARY_TV_APP_URL = "https://ais-dev-pzc2kbcbmy6soqn6ukeiny-637113962636.europe-west2.run.app";
    private static final String DIRECT_AKWAM_FALLBACK = "https://akwam.ss/one";

    private static final List<String> BLOCKED_AD_PATTERNS = Arrays.asList(
        "hide.js", "hide2.js", "akwam-notifications", "doubleclick.net",
        "googlesyndication.com", "popads.net", "popcash.net", "propellerads",
        "adsterra", "exoclick", "juicyads", "clickadu", "hilltopads",
        "adnxs.com", "taboola", "outbrain", "yandex.ru/metrika"
    );

    private WebView webView;
    private View customFullscreenView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private FrameLayout rootContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        rootContainer = new FrameLayout(this);
        rootContainer.setBackgroundColor(Color.parseColor("#0B0E14"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0B0E14"));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        // prevent multi-window popunders completely
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString().toLowerCase();
                for (String pattern : BLOCKED_AD_PATTERNS) {
                    if (url.contains(pattern)) {
                        return new WebResourceResponse(
                            "text/plain",
                            "utf-8",
                            new ByteArrayInputStream(new byte[0])
                        );
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase() : "";

                // Support MX Player (intent://) and VLC (vlc://) hardware video decoding on TX1-S
                if ("intent".equals(scheme)) {
                    try {
                        Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                        startActivity(intent);
                    } catch (Exception ignored) {}
                    return true;
                }
                if ("vlc".equals(scheme)) {
                    try {
                        String rawVideo = uri.toString().replaceFirst("^vlc://", "");
                        Intent vlcIntent = new Intent(Intent.ACTION_VIEW);
                        vlcIntent.setDataAndType(Uri.parse(rawVideo), "video/*");
                        startActivity(vlcIntent);
                    } catch (Exception ignored) {}
                    return true;
                }

                // Block external ad domain redirects if browsing fallback directly
                String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";
                boolean trusted = host.contains("run.app") || host.contains("akwam") ||
                                  host.contains("ak.sv") || host.contains("downet.net") ||
                                  host.contains("localhost");
                return !trusted;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Allow *.downet.net video mirror legacy CentOS SSL chains on Android 10
                String url = error.getUrl() != null ? error.getUrl().toLowerCase() : "";
                if (url.contains("downet.net") || url.contains("akwam")) {
                    handler.proceed();
                } else {
                    handler.cancel();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customFullscreenView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customFullscreenView = view;
                customViewCallback = callback;
                webView.setVisibility(View.GONE);
                rootContainer.addView(customFullscreenView);
            }

            @Override
            public void onHideCustomView() {
                if (customFullscreenView == null) return;
                rootContainer.removeView(customFullscreenView);
                customFullscreenView = null;
                webView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            }
        });

        rootContainer.addView(webView);
        setContentView(rootContainer);

        webView.loadUrl(PRIMARY_TV_APP_URL.isEmpty() ? DIRECT_AKWAM_FALLBACK : PRIMARY_TV_APP_URL);
        webView.requestFocus();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (customFullscreenView != null) {
                webView.getWebChromeClient().onHideCustomView();
                return true;
            }
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        // Critical 1GB DDR3 RAM protection on Mortal TX1-S
        if (webView != null && level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            webView.clearCache(false);
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            rootContainer.removeView(webView);
            webView.destroy();
        }
        super.onDestroy();
    }
}
